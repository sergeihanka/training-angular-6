import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FancyText } from './fancy-text/fancy-text.component';
import { FancyCheckbox } from './fancy-checkbox/fancy-checkbox.component';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    FancyText,
    FancyCheckbox
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
